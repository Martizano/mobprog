package com.example.inventoryorganizer;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class delete extends AppCompatActivity {

    private Button DelBttn, BackBttn, AddBttn, ModifyBttn, ViewBttn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_view);

        DelBttn = findViewById(R.id.prodid);
        BackBttn = findViewById(R.id.DBack);
        AddBttn = findViewById(R.id.DADD);
        ModifyBttn = findViewById(R.id.DMODIFY);
        ViewBttn= findViewById(R.id.DVIEW);

        BackBttn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        AddBttn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(delete.this, addActivity.class);
                startActivity(intent);
            }
        });

        ModifyBttn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(delete.this, modify.class);
                startActivity(intent);
            }
        });

        ViewBttn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(delete.this, view.class);
                startActivity(intent);
            }
        });
    }
}